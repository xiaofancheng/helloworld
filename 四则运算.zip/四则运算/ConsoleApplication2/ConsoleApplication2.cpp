#include "stdafx.h"
#include<stdio.h>
#include<math.h>
#include<string.h>
#include<conio.h>
#include<windows.h>
#include<time.h>
int right = 0;
int wrong = 0;
void iAdd()
{
	int a, b, c;
	srand((unsigned)time(NULL));
	a = rand() % 100;
	b = rand() % 100;
	printf("��ش�\n\t\t\t\t %d + %d = ", a, b);
	scanf_s("%d", &c);
	if (a + b == c)
	{
		printf("�ش���ȷ!\n");
		right++;
	}
	else
	{
		printf("�ش����!\n");
		wrong++;
	}
}
void fAdd()
{
	int a1, a2, b1, b2, i, j;
	char a[10];
	int x, y;
	int x1, y1;
	x1 = y1 = 0;
	srand((unsigned)time(NULL));
	while (1)
	{
		a1 = rand() % 10;
		while (1)
		{
			a2 = rand() % 10;
			if (a2)
				break;
		}
		if (a1 < a2)
			break;
	}

	while (1)
	{
		b1 = rand() % 10;
		while (1)
		{
			b2 = rand() % 10;
			if (b2)
				break;
		}
		if (b1 < b2)
			break;
	}


	x = a1*b2 + a2*b1;
	y = a2*b2;
	if (x < y)
		i = x;
	else
		i = y;
	while (i>1)
	{
		if (x%i == 0 && y%i == 0)
		{
			x = x / i;
			y = y / i;
			continue;
		}
		i--;
	}

	printf("��ش�\n\t\t\t\t %d/%d + %d/%d = ", a1, a2, b1, b2);
	i = 0;
	while (1)
	{
		a[i] = _getche();
		if (a[i] == '/')
			break;
		i++;

	}
	scanf_s("%d", &y1);
	for (j = 0; j < i; j++)
	{
		x1 = x1 + pow(10, (i - 1 - j))*(a[j] - '0');
	}
	if (x1 == x&&y1 == y)
	{
		printf("�ش���ȷ!\n");
		right++;
	}
	else
	{
		printf("�ش����!\n");
		wrong++;
	}

}
void iMinu()
{
	int a, b, c;
	srand((unsigned)time(NULL));
	a = rand() % 100;
	b = rand() % 100;
	printf("��ش�\n\t\t\t\t %d - %d = ", a, b);
	scanf_s("%d", &c);
	if (a - b == c)
	{
		printf("�ش���ȷ!\n");
		right++;
	}
	else
	{
		printf("�ش����!\n");
		wrong++;
	}
}
void fMinu()
{
	int a1, a2, b1, b2, i;
	char a[10];
	int x, y, j;
	int x1, y1;
	srand((unsigned)time(NULL));
	while (1)
	{
		a1 = rand() % 10;
		while (1)
		{
			a2 = rand() % 10;
			if (a2)
				break;
		}
		if (a1 < a2)
			break;
	}

	while (1)
	{
		b1 = rand() % 10;
		while (1)
		{
			b2 = rand() % 10;
			if (b2)
				break;
		}
		if (b1 < b2)
			break;
	}

	x = a1*b2 - a2*b1;
	y = a2*b2;
	if (x < y)
		i = x;
	else
		i = y;
	while (i>0)
	{
		if (x%i == 0 && y%i == 0)
		{
			x = x / i;
			y = y / i;
		}
		i--;
	}

	printf("��ش�\n\t\t\t\t %d/%d - %d/%d = ", a1, a2, b1, b2);
	i = 0;
	while (1)
	{
		a[i] = _getche();
		if (a[i] == '/')
			break;
		i++;

	}
	scanf_s("%d", &y1);
	x1 = 0;
	for (j = 0; j < i; j++)
	{
		x1 = x1 + pow(10, (i - 1 - j))*(a[j] - '0');
	}
	if (x1 == x&&y1 == y)
	{
		printf("�ش���ȷ!\n");
		right++;
	}
	else
	{
		printf("�ش����!\n");
		wrong++;
	}

}
void iMul()
{
	int a, b, c;
	srand((unsigned)time(NULL));
	a = rand() % 100;
	b = rand() % 100;
	printf("��ش�\n\t\t\t\t %d * %d = ", a, b);
	scanf_s("%d", &c);
	if (a*b == c)
	{
		printf("�ش���ȷ!\n");
		right++;
	}
	else
	{
		printf("�ش����!\n");
		wrong++;
	}
}
void fMul()
{
	int a1, a2, b1, b2, i, j;
	char a[10];
	int x, y;
	int x1, y1;
	srand((unsigned)time(NULL));
	while (1)
	{
		a1 = rand() % 10;
		while (1)
		{
			a2 = rand() % 10;
			if (a2)
				break;
		}
		if (a1 < a2)
			break;
	}

	while (1)
	{
		b1 = rand() % 10;
		while (1)
		{
			b2 = rand() % 10;
			if (b2)
				break;
		}
		if (b1 < b2)
			break;
	}

	x = a1*b1;
	y = a2*b2;
	if (x < y)
		i = x;
	else
		i = y;
	while (i>0)
	{
		if (x%i == 0 && y%i == 0)
		{
			x = x / i;
			y = y / i;
		}
		i--;
	}

	printf("��ش�\n\t\t\t\t %d/%d * %d/%d = ", a1, a2, b1, b2);
	i = 0;
	while (1)
	{
		a[i] = _getche();
		if (a[i] == '/')
			break;
		i++;

	}
	scanf_s("%d", &y1);
	x1 = 0;
	for (j = 0; j < i; j++)
	{
		x1 = x1 + pow(10, (i - 1 - j))*(a[j] - '0');
	}
	if (x1 == x&&y1 == y)
	{
		printf("�ش���ȷ!\n");
		right++;
	}
	else
	{
		printf("�ش����!\n");
		wrong++;
	}

}
void iDi()
{
	int a, b, c;
	srand((unsigned)time(NULL));
	a = rand() % 100;
	b = rand() % 100;
	printf("��ش�\n\t\t\t\t %d / %d = ", a, b);
	scanf_s("%d", &c);
	if (a / b == c)
	{
		printf("�ش���ȷ!\n");
		right++;
	}
	else
	{
		printf("�ش����!\n");
		wrong++;
	}
}
void fDi()
{
	int a1, a2, b1, b2, i;
	char a[10];
	int x, y, j, k;
	int x1, y1;
	srand((unsigned)time(NULL));
	while (1)
	{
		a1 = rand() % 10;
		while (1)
		{
			a2 = rand() % 10;
			if (a2)
				break;
		}
		if (a1 < a2)
			break;
	}

	while (1)
	{
		b1 = rand() % 10;
		while (1)
		{
			b2 = rand() % 10;
			if (b2)
				break;
		}
		if (b1 < b2)
			break;
	}

	x = a1*b2;
	y = a2*b1;
	if (x < y)
		i = x;
	else
		i = y;
	while (i>0)
	{
		if (x%i == 0 && y%i == 0)
		{
			x = x / i;
			y = y / i;
		}
		i--;
	}

	printf("��ش�\n\t\t\t\t %d/%d / %d/%d = ", a1, a2, b1, b2);
	i = 0;
	while (1)
	{
		a[i] = _getche();
		if (a[i] == '/')
			break;
		i++;

	}
	scanf_s("%d", &y1);
	x1 = 0;
	for (j = 0; j < i; j++)
	{
		x1 = x1 + pow(10, (i - 1 - j))*(a[j] - '0');
	}
	if (x1 == x&&y1 == y)
	{
		printf("�ش���ȷ!\n");
		right++;
	}
	else
	{
		printf("�ش����!\n");
		wrong++;
	}

}
void main()
{
	int choise1, choise2;
	int con = 0;
	printf("\n\t\t\t\t\t�Զ�������������\n\n");
	while (1)
	{
		printf("\t\t\t\t\t  1.��������\n");
		printf("\t\t\t\t\t  2.��������\n");
		if (con == 0)
			scanf_s("%d", &choise1);
		system("cls");
		printf("\t\t\t\t\t  1.�ӷ�����\n");
		printf("\t\t\t\t\t  2.��������\n");
		printf("\t\t\t\t\t  3.�˷�����\n");
		printf("\t\t\t\t\t  4.��������\n");
		printf("\t\t\t\t\t  5.�˳�����\n");
		printf("��ѡ��\n");
		if (con == 0)
			scanf_s("%d", &choise2);
		system("cls");
		switch (choise2)
		{
		case 1:
			if (choise1 == 1)
				iAdd();
			else
				fAdd();
			break;
		case 2:
			if (choise1 == 1)
				iMinu();
			else
				fMinu();
			break;
		case 3:
			if (choise1 == 1)
				iMul();
			else
				fMul();
			break;
		case 4:
			if (choise1 == 1)
				iDi();
			else
				fDi();
			break;
		case 5:
			return;
		}
		printf("\n\t\t\t1.�������㣿\n");
		printf("\n\t\t\t2.����ѡ��\n");
		printf("\n\t\t\t3.�˳����㣿\n");
		scanf_s("%d", &con);
		if (con == 1)
			con = 1;
		else if (con == 2)
		{
			system("cls");
			con = 0;
		}
		else if (con == 3)
			break;
	}
	printf("�ܹ������ %d ����\n��ȷ %d ��\n���� %d ��\n", right + wrong, right, wrong);
	printf("�÷�Ϊ%d\n", right);
	system("pause");
}